const express = require('express')
const router = express.Router()

const UserController = require('../controllers/images.js')

router.get('/',UserController.getAllImages)
router.get('/:id',UserController.getImage)  
router.post('/add',UserController.addImage)  
router.put('/update/:id',UserController.updateImage) 
router.delete('/delete/:id',UserController.deleteImage)  

module.exports = router