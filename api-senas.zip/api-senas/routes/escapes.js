const express = require('express')
const router = express.Router()

const UserController = require('../controllers/escapes.js')

router.get('/',UserController.getAllEscapes)
router.get('/:id',UserController.getEscape)  
router.post('/add',UserController.addEscape)  
router.put('/update/:id',UserController.updateEscape) 
router.delete('/delete/:id',UserController.deleteEscape)  

module.exports = router