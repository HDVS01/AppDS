const express = require('express')
const router = express.Router()
//rutas para usuarios
router.use('/users',require('./users.js'))
router.use('/categories',require('./categories.js'))
router.use('/images',require('./images.js'))
router.use('/objects',require('./objects.js'))
router.use('/video_clues',require('./video_clues.js'))
router.use('/escapes',require('./escapes.js'))
router.use('/sessions',require('./sessions.js'))
router.use('/escapes_objects',require('./escapes_objects.js'))


module.exports = router