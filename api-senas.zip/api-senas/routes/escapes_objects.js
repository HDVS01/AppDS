const express = require('express')
const router = express.Router()

const UserController = require('../controllers/escapes_objects.js')

router.get('/getRecent',UserController.getRecentEscape_objects)  
router.get('/objects/:id',UserController.getObjectEscapes_objects)  

router.get('/',UserController.getAllEscapes_Objects)
router.get('/:id',UserController.getEscape_Object) 



router.post('/add',UserController.addEscape_Object)
router.post('/addWithRecentEscape',UserController.addWithRecentEscape)

router.put('/update/:id',UserController.updateEscape_Object) 
router.delete('/delete/:id',UserController.deleteEscape_Object)  

module.exports = router