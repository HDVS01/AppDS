const express = require('express')
const router = express.Router()

const UserController = require('../controllers/sessions.js')

router.get('/',UserController.getAllSessions)
router.get('/:id',UserController.getSession)  
router.post('/add',UserController.addSession)  
router.put('/update/:id',UserController.updateSession) 
router.delete('/delete/:id',UserController.deleteSession)  

module.exports = router