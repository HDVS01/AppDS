const express = require('express')
const router = express.Router()

const UserController = require('../controllers/categories.js')

router.get('/',UserController.getAllCategories)
router.get('/:id',UserController.getCategory)  
router.post('/add',UserController.addCategory)  
router.put('/update/:id',UserController.updateCategory) 
router.delete('/delete/:id',UserController.deleteCategory)  

module.exports = router