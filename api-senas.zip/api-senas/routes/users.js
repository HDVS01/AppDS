const express = require('express')
const router = express.Router()

const UserController = require('../controllers/users.js')

router.get('/',UserController.getAllUsers)
router.get('/:id',UserController.getUser)  
router.post('/add',UserController.addUser)  
router.put('/update/:id',UserController.updateUser) 
router.delete('/delete/:id',UserController.deleteUser)  

module.exports = router