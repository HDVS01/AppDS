const express = require('express')
const router = express.Router()

const UserController = require('../controllers/video_clues.js')

router.get('/',UserController.getAllVideo_Clues)
router.get('/:id',UserController.getVideo_Clue)  
router.post('/add',UserController.addVideo_Clue)  
router.put('/update/:id',UserController.updateVideo_Clue) 
router.delete('/delete/:id',UserController.deleteVideo_Clue)  

module.exports = router