const express = require('express')
const router = express.Router()

const UserController = require('../controllers/objects.js')

router.get('/',UserController.getAllObjects)
router.get('/:id',UserController.getObject)
router.get('/category/:id_category',UserController.getObjectCategory)  
router.post('/add',UserController.addObject)  
router.put('/update/:id',UserController.updateObject) 
router.delete('/delete/:id',UserController.deleteObject)  

module.exports = router