const dbService = require('../config/db.js')
module.exports = {
    getAllUsers : () => {
        sql = 'SELECT * FROM usuario'
        return dbService.querypromise(sql)

    },
    getUser : (id) => {
        sql = `SELECT * FROM usuario WHERE id = ${id}`
        return dbService.querypromise(sql)

    },
    addUser : (body) => {
        const {email} = body
        sql = `insert INTO usuario(email) VALUES('${email}') RETURNING *`
        return dbService.querypromise(sql)

    },
    updateUser : (id, body) => {
        const {email} = body
        sql = `UPDATE usuario SET email ='${email}' WHERE id = '${id}' RETURNING *`
        return dbService.querypromise(sql)

    },
    delteUser : (id, body) => {
        
        sql = `DELETE FROM usuario WHERE id = ${id} RETURNING *`
        return dbService.querypromise(sql)

    }
    // aqui agregar las otras funciones 
}