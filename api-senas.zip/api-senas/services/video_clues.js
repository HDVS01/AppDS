const dbService = require('../config/db.js')
module.exports = {
    getAllVideo_Clues : () => {
        sql = 'SELECT * FROM video_clues'
        return dbService.querypromise(sql)

    },
    getVideo_Clues : (id) => {
        sql = `SELECT * FROM video_clues WHERE id = ${id}`
        return dbService.querypromise(sql)

    },
    addVideo_Clues : (body) => {
        const {DURATION, DIFICULTY, OBJECTS_ID, URL, DATE_OF_CREATION, ACTIVE} = body
        sql = `insert INTO video_clues(DURATION, DIFICULTY, OBJECTS_ID, URL, DATE_OF_CREATION, ACTIVE)
         VALUES('${DURATION}','${DIFICULTY}',${OBJECTS_ID},'${URL}','${DATE_OF_CREATION}','${ACTIVE}' ) 
         RETURNING *`
        return dbService.querypromise(sql)

    },
    updateVideo_Clues : (id, body) => {
        const {DURATION, DIFICULTY, OBJECTS_ID, URL, DATE_OF_CREATION, ACTIVE} = body
        sql = `UPDATE video_clues 
        SET DURATION ='${DURATION}', DIFICULTY = '${DIFICULTY}',OBJECTS_ID = ${OBJECTS_ID}, URL = '${URL}' , DATE_OF_CREATION ='${DATE_OF_CREATION}', ACTIVE = '${ACTIVE}'  WHERE id = '${id}' RETURNING *`
        return dbService.querypromise(sql)

    },
    deleteVideo_Clues : (id) => {
        
        sql = `DELETE FROM video_clues WHERE id = ${id} RETURNING *`
        return dbService.querypromise(sql)

    }
    // aqui agregar las otras funciones 
}