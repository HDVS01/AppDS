const dbService = require('../config/db.js')
module.exports = {
    getAllCategories : () => {
        sql = 'SELECT * FROM categories'
        return dbService.querypromise(sql)

    },
    getCategory : (id) => {
        sql = `SELECT * FROM categories WHERE id = ${id}`
        return dbService.querypromise(sql)

    },
    addCategory : (body) => {
        const {TITLE,DATE_OF_CREATION,ACTIVE} = body
        sql = `insert INTO categories(TITLE,DATE_OF_CREATION,ACTIVE) VALUES('${TITLE}','${DATE_OF_CREATION}','${ACTIVE}' ) RETURNING *`
        return dbService.querypromise(sql)

    },
    updateCategory : (id, body) => {
        const {TITLE,DATE_OF_CREATION,ACTIVE} = body
        sql = `UPDATE categories SET TITLE ='${TITLE}' , DATE_OF_CREATION ='${DATE_OF_CREATION}', ACTIVE = '${ACTIVE}'  WHERE id = '${id}' RETURNING *`
        return dbService.querypromise(sql)

    },
    deleteCategory : (id) => {
        
        sql = `DELETE FROM categories WHERE id = ${id} RETURNING *`
        return dbService.querypromise(sql)

    }
    // aqui agregar las otras funciones 
}