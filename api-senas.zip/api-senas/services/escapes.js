const dbService = require('../config/db.js')
module.exports = {
    getAllEscapes : () => {
        sql = 'SELECT * FROM escapes'
        return dbService.querypromise(sql)

    },
    getEscape : (id) => {
        sql = `SELECT * FROM escapes WHERE id = ${id}`
        return dbService.querypromise(sql)

    },
    addEscape : (body) => {
        const {TITLE, DESCRIPTION, VISIBILITY, APPLEID_CREATOR, DATE_OF_CREATION, ACTIVE,CATEGORIES_ID} = body
        sql = `
        CREATE SEQUENCE IF NOT EXISTS escapes_item_id;
        insert INTO escapes(TITLE, DESCRIPTION, VISIBILITY, APPLEID_CREATOR, DATE_OF_CREATION, ACTIVE,CATEGORIES_ID) 
        VALUES('${TITLE}','${DESCRIPTION}','${VISIBILITY}','${APPLEID_CREATOR}','${DATE_OF_CREATION}','${ACTIVE}',${CATEGORIES_ID} ) RETURNING *;`
        return dbService.querypromise(sql)

    },
    updateEscape : (id, body) => {
        const {TITLE, DESCRIPTION, VISIBILITY, APPLEID_CREATOR, DATE_OF_CREATION, ACTIVE,CATEGORIES_ID} = body
        sql = `UPDATE escapes 
        SET TITLE ='${TITLE}',DESCRIPTION = '${DESCRIPTION}',VISIBILITY = '${VISIBILITY}', APPLEID_CREATOR = '${APPLEID_CREATOR}', DATE_OF_CREATION ='${DATE_OF_CREATION}', ACTIVE = '${ACTIVE}',CATEGORIES_ID = ${CATEGORIES_ID}
          WHERE id = '${id}' RETURNING *`
        return dbService.querypromise(sql)

    },
    deleteEscape : (id) => {
        
        sql = `DELETE FROM escapes WHERE id = ${id} RETURNING *`
        return dbService.querypromise(sql)

    }
    // aqui agregar las otras funciones 
}