const dbService = require('../config/db.js')
module.exports = {
    getAllImages : () => {
        sql = 'SELECT * FROM images'
        return dbService.querypromise(sql)

    },
    getImage : (id) => {
        sql = `SELECT * FROM images WHERE id = ${id}`
        return dbService.querypromise(sql)

    },
    addImage : (body) => {
        const {DESCRIPTION, URL, FORMAT, DATE_OF_CREATION, ACTIVE} = body
        sql = `insert INTO images(DESCRIPTION, URL, FORMAT, DATE_OF_CREATION, ACTIVE) 
        VALUES('${DESCRIPTION}','${URL}','${FORMAT}','${DATE_OF_CREATION}','${ACTIVE}' ) 
        RETURNING *`
        return dbService.querypromise(sql)

    },
    updateImage : (id, body) => {
        const {DESCRIPTION, URL, FORMAT, DATE_OF_CREATION, ACTIVE} = body
        sql = `UPDATE images 
        SET DESCRIPTION ='${DESCRIPTION}', URL ='${URL}',FORMAT ='${FORMAT}', DATE_OF_CREATION ='${DATE_OF_CREATION}', ACTIVE = '${ACTIVE}'  
        WHERE id = '${id}' RETURNING *`
        return dbService.querypromise(sql)

    },
    deleteImage : (id) => {
        
        sql = `DELETE FROM images WHERE id = ${id} RETURNING *`
        return dbService.querypromise(sql)

    }
    // aqui agregar las otras funciones 
}