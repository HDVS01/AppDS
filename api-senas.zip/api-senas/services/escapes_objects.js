const dbService = require('../config/db.js')
module.exports = {
    getAllEscapes_Objects : () => {
        sql = 'SELECT * FROM escapes_objects'
        return dbService.querypromise(sql)

    },
    getEscape_Object : (id) => {
        sql = `SELECT * FROM escapes_objects WHERE id = ${id}`
        return dbService.querypromise(sql)

    },
    addEscape_Object : (body) => {
        const {ESCAPES_ID, OBJECTS_ID, VIDEO_CLUES_ID, DATE_OF_CREATION, ACTIVE} = body
        sql = `insert INTO escapes_objects(ESCAPES_ID, OBJECTS_ID, VIDEO_CLUES_ID, DATE_OF_CREATION, ACTIVE) 
        VALUES(${ESCAPES_ID},${OBJECTS_ID},${VIDEO_CLUES_ID},'${DATE_OF_CREATION}','${ACTIVE}' ) RETURNING *`
        return dbService.querypromise(sql)

    },
    updateEscape_Object : (id, body) => {
        const {ESCAPES_ID, OBJECTS_ID, VIDEO_CLUES_ID, DATE_OF_CREATION, ACTIVE} = body
        sql = `UPDATE escapes_objects 
        SET ESCAPES_ID =${ESCAPES_ID},OBJECTS_ID =${OBJECTS_ID},VIDEO_CLUES_ID =${VIDEO_CLUES_ID} , DATE_OF_CREATION ='${DATE_OF_CREATION}', ACTIVE = '${ACTIVE}'  WHERE id = '${id}' RETURNING *`
        return dbService.querypromise(sql)

    },
    deleteEscape_Object : (id) => {
        
        sql = `DELETE FROM escapes_objects WHERE id = ${id} RETURNING *`
        return dbService.querypromise(sql)

    },
    addWithRecentEscape : (body) => {
        const {OBJECTS_ID, VIDEO_CLUES_ID, DATE_OF_CREATION, ACTIVE} = body
        sql = `
        -- Encuentra el valor máximo actual en la columna "id" de la tabla "escapes"
        DO $$
        DECLARE
            max_id INT;
        BEGIN
            SELECT MAX(id) INTO max_id FROM escapes;
            
            -- Establece el valor de la secuencia escapes_item_id al valor máximo + 1
            IF max_id IS NOT NULL THEN
                -- Si existen registros en la tabla escapes, establece el valor de la secuencia
                -- al máximo valor + 1
                EXECUTE 'SELECT setval(''escapes_item_id'', ' || max_id + 1 || ')';
            ELSE
                -- Si la tabla escapes está vacía, inicia la secuencia desde 1
                EXECUTE 'SELECT setval(''escapes_item_id'', 1)';
            END IF;
        END $$;
        insert INTO escapes_objects(ESCAPES_ID, OBJECTS_ID, VIDEO_CLUES_ID, DATE_OF_CREATION, ACTIVE) 
        VALUES(currval('escapes_item_id') - 1,${OBJECTS_ID},${VIDEO_CLUES_ID},'${DATE_OF_CREATION}','${ACTIVE}' ) RETURNING *`
        return dbService.querypromise(sql)

    },
    getRecentEscape_objects : () => {
        sql = `
        SELECT O.*
        FROM ESCAPES_OBJECTS EO
        JOIN OBJECTS O ON EO.OBJECTS_ID = O.ID
        WHERE EO.ESCAPES_ID = (SELECT MAX(ID)  FROM OBJECTS) - 1;
        `
        
        return dbService.querypromise(sql)

    },
    getObjectEscapes_objects : (id) => {
        sql = `SELECT O.*
        FROM ESCAPES_OBJECTS EO
        JOIN OBJECTS O ON EO.OBJECTS_ID = O.ID
        WHERE EO.ESCAPES_ID = ${id}`
        return dbService.querypromise(sql)

    },
    // aqui agregar las otras funciones 
}