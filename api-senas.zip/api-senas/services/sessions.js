const dbService = require('../config/db.js')
module.exports = {
    getAllSessions : () => {
        sql = 'SELECT * FROM sessions'
        return dbService.querypromise(sql)

    },
    getSession : (id) => {
        sql = `SELECT * FROM sessions WHERE id = ${id}`
        return dbService.querypromise(sql)

    },
    addSession : (body) => {
        const {ESCAPES_ID, CODE, DATE_OF_CREATION, ACTIVE} = body
        sql = `insert INTO sessions(ESCAPES_ID, CODE, DATE_OF_CREATION, ACTIVE) 
        VALUES(${ESCAPES_ID},${CODE},'${DATE_OF_CREATION}','${ACTIVE}' ) RETURNING *`
        return dbService.querypromise(sql)

    },
    updateSession : (id, body) => {
        const {ESCAPES_ID, CODE, DATE_OF_CREATION, ACTIVE} = body
        sql = `UPDATE sessions SET ESCAPES_ID =${ESCAPES_ID}, CODE =${CODE} , DATE_OF_CREATION ='${DATE_OF_CREATION}', ACTIVE = '${ACTIVE}'  
        WHERE id = '${id}' RETURNING *`
        return dbService.querypromise(sql)

    },
    deleteSession : (id) => {
        
        sql = `DELETE FROM sessions WHERE id = ${id} RETURNING *`
        return dbService.querypromise(sql)

    }
    // aqui agregar las otras funciones 
}