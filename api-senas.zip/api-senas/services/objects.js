const dbService = require('../config/db.js')
module.exports = {
    getAllObjects : () => {
        sql = 'SELECT * FROM objects'
        return dbService.querypromise(sql)

    },
    getObject : (id) => {
        sql = `SELECT * FROM objects WHERE id = ${id}`
        return dbService.querypromise(sql)

    },
    addObject : (body) => {
        const {NAME, CATEGORIES_ID, IMAGES_ID, DATE_OF_CREATION, ACTIVE} = body
        sql = `insert INTO objects(NAME, CATEGORIES_ID, IMAGES_ID, DATE_OF_CREATION, ACTIVE) VALUES('${NAME}',${CATEGORIES_ID},${IMAGES_ID},'${DATE_OF_CREATION}','${ACTIVE}' ) RETURNING *`
        return dbService.querypromise(sql)

    },
    updateObject : (id, body) => {
        const {NAME, CATEGORIES_ID, IMAGES_ID, DATE_OF_CREATION, ACTIVE} = body
        sql = `UPDATE objects 
        SET NAME ='${NAME}' , CATEGORIES_ID = ${CATEGORIES_ID},IMAGES_ID = ${IMAGES_ID}  , DATE_OF_CREATION ='${DATE_OF_CREATION}', ACTIVE = '${ACTIVE}' 
         WHERE id = '${id}' 
         RETURNING *`
        return dbService.querypromise(sql)

    },
    deleteObject : (id) => {
        
        sql = `DELETE FROM objects WHERE id = ${id} RETURNING *`
        return dbService.querypromise(sql)

    },
    getObjectCategory : (id_category) => {
        sql = `SELECT * FROM objects WHERE categories_id = ${id_category}`
        return dbService.querypromise(sql)

    },
    // aqui agregar las otras funciones 
}