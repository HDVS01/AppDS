const UserServices = require('../services/users.js')
module.exports = {
    getAllUsers : async(req,res,next) => {
        try{
            const users = await UserServices.getAllUsers()

            res.json(users)
        } catch(err){
            res.json({"message": 'error al obtener los usuarios . Err: ${err}'})
        }
       
    },
    getUser: async(req,res) => {
        const id = req.params.id
        try{
            const user = await UserServices.getUser(id)

            res.json(users)
        } catch(err){
            res.json({"message": `error al obtener el usuario . Err: ${err}`})
        }
       
    },
    addUser: async(req,res) => {
        // aqui solo tengo un campo en la base pero haqu que agregar comas si hay mas
        const body = req.body
        try{
            const user = await UserServices.addUser(body)

            res.status(200).json(users)
        } catch(err){
            res.status(500).json({"message": `error al agregar el usuario . Err: ${err}`})
        }
       
    },
    updateUser: async(req,res) => {
        // aqui solo tengo un campo en la base pero haqu que agregar comas si hay mas
        const id = req.params.id
        const body = req.body
        try{
            const user = await UserServices.updateUser(id, body)

            res.status(200).json(users)
        } catch(err){
            res.status(500).json({"message": `error al actualizar el usuario . Err: ${err}`})
        }
       
    },

    deleteUser: async(req,res) => {
        // aqui solo tengo un campo en la base pero haqu que agregar comas si hay mas
        const id = req.params.id
        try{
            const user = await UserServices.updateUser(id)

            res.status(200).json(users)
        } catch(err){
            res.status(500).json({"message": `error al borrar el usuario . Err: ${err}`})
        }
       
    },
    // aqui agregar las otras funciones 
}