const UserServices = require('../services/categories.js')
module.exports = {
    getAllCategories : async(req,res,next) => {
        try{
            const users = await UserServices.getAllCategories()

            res.json(users)
        } catch(err){
            res.json({"message": 'error al obtener las categorias . Err: ${err}'})
        }
       
    },
    getCategory: async(req,res) => {
        const id = req.params.id
        try{
            const user = await UserServices.getCategory(id)

            res.json(users)
        } catch(err){
            res.json({"message": `error al obtener la categoria . Err: ${err}`})
        }
       
    },
    addCategory: async(req,res) => {
        // aqui solo tengo un campo en la base pero haqu que agregar comas si hay mas
        const body = req.body
        try{
            const user = await UserServices.addCategory(body)

            res.status(200).json(user)
        } catch(err){
            res.status(500).json({"message": `error al agregar el usuario . Err: ${err}`})
        }
       
    },
    updateCategory: async(req,res) => {
        // aqui solo tengo un campo en la base pero haqu que agregar comas si hay mas
        const id = req.params.id
        const body = req.body
        try{
            const user = await UserServices.updateCategory(id, body)

            res.status(200).json(user)
        } catch(err){
            res.status(500).json({"message": `error al actualizar la categoria . Err: ${err}`})
        }
       
    },

    deleteCategory: async(req,res) => {
        // aqui solo tengo un campo en la base pero haqu que agregar comas si hay mas
        const id = req.params.id
        try{
            const user = await UserServices.deleteCategory(id)

            res.status(200).json(user)
        } catch(err){
            res.status(500).json({"message": `error al borrar la categoria . Err: ${err}`})
        }
       
    },
    // aqui agregar las otras funciones 
}