const UserServices = require('../services/objects.js')
module.exports = {
    getAllObjects : async(req,res,next) => {
        try{
            const users = await UserServices.getAllObjects()

            res.json(users)
        } catch(err){
            res.json({"message": 'error al obtener los objetos . Err: ${err}'})
        }
       
    },
    getObject: async(req,res) => {
        const id = req.params.id
        try{
            const user = await UserServices.getObject(id)

            res.json(user)
        } catch(err){
            res.json({"message": `error al obtener el objeto . Err: ${err}`})
        }
       
    },
    addObject: async(req,res) => {
        // aqui solo tengo un campo en la base pero haqu que agregar comas si hay mas
        const body = req.body
        try{
            const user = await UserServices.addObject(body)

            res.status(200).json(user)
        } catch(err){
            res.status(500).json({"message": `error al agregar el objeto . Err: ${err}`})
        }
       
    },
    updateObject: async(req,res) => {
        // aqui solo tengo un campo en la base pero haqu que agregar comas si hay mas
        const id = req.params.id
        const body = req.body
        try{
            const user = await UserServices.updateObject(id, body)

            res.status(200).json(user)
        } catch(err){
            res.status(500).json({"message": `error al actualizar la objeto . Err: ${err}`})
        }
       
    },

    deleteObject: async(req,res) => {
        // aqui solo tengo un campo en la base pero haqu que agregar comas si hay mas
        const id = req.params.id
        try{
            const user = await UserServices.deleteObject(id)

            res.status(200).json(user)
        } catch(err){
            res.status(500).json({"message": `error al borrar la categoria . Err: ${err}`})
        }
       
    },
    getObjectCategory : async(req,res,next) => {
        const id_category = req.params.id_category
        try{
            const users = await UserServices.getObjectCategory(id_category)

            res.json(users)
        } catch(err){
            res.json({"message": `error al obtener los objetos con esa categoria . Err: ${err}`})
        }
       
    },
    // aqui agregar las otras funciones 
}