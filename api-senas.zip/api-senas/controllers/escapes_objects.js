const UserServices = require('../services/escapes_objects.js')
module.exports = {
    getAllEscapes_Objects : async(req,res,next) => {
        try{
            const users = await UserServices.getAllEscapes_Objects()

            res.json(users)
        } catch(err){
            res.json({"message": 'error al obtener los escapes_objects . Err: ${err}'})
        }
       
    },
    getEscape_Object: async(req,res) => {
        const id = req.params.id
        try{
            const user = await UserServices.getEscape_Object(id)

            res.json(user)
        } catch(err){
            res.json({"message": `error al obtener la escape_object . Err: ${err}`})
        }
       
    },
    addEscape_Object: async(req,res) => {
        // aqui solo tengo un campo en la base pero haqu que agregar comas si hay mas
        const body = req.body
        try{
            const user = await UserServices.addEscape_Object(body)

            res.status(200).json(user)
        } catch(err){
            res.status(500).json({"message": `error al agregar el escape_object . Err: ${err}`})
        }
       
    },
    updateEscape_Object: async(req,res) => {
        // aqui solo tengo un campo en la base pero haqu que agregar comas si hay mas
        const id = req.params.id
        const body = req.body
        try{
            const user = await UserServices.updateEscape_Object(id, body)

            res.status(200).json(user)
        } catch(err){
            res.status(500).json({"message": `error al actualizar el escape_object . Err: ${err}`})
        }
       
    },

    deleteEscape_Object: async(req,res) => {
        // aqui solo tengo un campo en la base pero haqu que agregar comas si hay mas
        const id = req.params.id
        try{
            const user = await UserServices.deleteEscape_Object(id)

            res.status(200).json(user)
        } catch(err){
            res.status(500).json({"message": `error al borrar la categoria . Err: ${err}`})
        }
       
    },
    addWithRecentEscape: async(req,res) => {
        // aqui solo tengo un campo en la base pero haqu que agregar comas si hay mas
        const body = req.body
        try{
            const user = await UserServices.addWithRecentEscape(body)

            res.status(200).json(user)
        } catch(err){
            res.status(500).json({"message": `error al agregar el escape . Err: ${err}`})
        }
       
    },
    getRecentEscape_objects: async(req,res) => {
        try{
            const users = await UserServices.getRecentEscape_objects()

            res.status(200).json(users)
        } catch(err){
            res.json({"message": `error al obtener los escapes_objects . Err: ${err}`})
        }
       
    },
    getObjectEscapes_objects: async(req,res) => {
        const id = req.params.id
        try{
            const user = await UserServices.getObjectEscapes_objects(id)
            
            res.status(200).json(user)
        } catch(err){
            res.json({"message": `error al obtener la escape_object . Err: ${err}`})
        }
       
    }
    // aqui agregar las otras funciones 
    
}