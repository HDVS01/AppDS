const UserServices = require('../services/escapes.js')
module.exports = {
    getAllEscapes : async(req,res,next) => {
        try{
            const users = await UserServices.getAllEscapes()

            res.json(users)
        } catch(err){
            res.json({"message": 'error al obtener los escapes . Err: ${err}'})
        }
       
    },
    getEscape: async(req,res) => {
        const id = req.params.id
        try{
            const user = await UserServices.getEscape(id)

            res.json(user)
        } catch(err){
            res.json({"message": `error al obtener el escape . Err: ${err}`})
        }
       
    },
    addEscape: async(req,res) => {
        // aqui solo tengo un campo en la base pero haqu que agregar comas si hay mas
        const body = req.body
        try{
            const user = await UserServices.addEscape(body)

            res.status(200).json(user)
        } catch(err){
            res.status(500).json({"message": `error al agregar el escape . Err: ${err}`})
        }
       
    },
    updateEscape: async(req,res) => {
        // aqui solo tengo un campo en la base pero haqu que agregar comas si hay mas
        const id = req.params.id
        const body = req.body
        try{
            const user = await UserServices.updateEscape(id, body)

            res.status(200).json(user)
        } catch(err){
            res.status(500).json({"message": `error al actualizar el escape . Err: ${err}`})
        }
       
    },

    deleteEscape: async(req,res) => {
        // aqui solo tengo un campo en la base pero haqu que agregar comas si hay mas
        const id = req.params.id
        try{
            const user = await UserServices.deleteEscape(id)

            res.status(200).json(user)
        } catch(err){
            res.status(500).json({"message": `error al borrar la categoria . Err: ${err}`})
        }
       
    },
    // aqui agregar las otras funciones 
}