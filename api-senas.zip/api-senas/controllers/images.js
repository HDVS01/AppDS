const UserServices = require('../services/images.js')
module.exports = {
    getAllImages : async(req,res,next) => {
        try{
            const users = await UserServices.getAllImages()

            res.json(users)
        } catch(err){
            res.json({"message": 'error al obtener las imagenes . Err: ${err}'})
        }
       
    },
    getImage: async(req,res) => {
        const id = req.params.id
        try{
            const user = await UserServices.getImage(id)

            res.json(user)
        } catch(err){
            res.json({"message": `error al obtener la imagen . Err: ${err}`})
        }
       
    },
    addImage: async(req,res) => {
        // aqui solo tengo un campo en la base pero haqu que agregar comas si hay mas
        const body = req.body
        try{
            const user = await UserServices.addImage(body)

            res.status(200).json(user)
        } catch(err){
            res.status(500).json({"message": `error al agregar la imagen . Err: ${err}`})
        }
       
    },
    updateImage: async(req,res) => {
        // aqui solo tengo un campo en la base pero haqu que agregar comas si hay mas
        const id = req.params.id
        const body = req.body
        try{
            const user = await UserServices.updateImage(id, body)

            res.status(200).json(user)
        } catch(err){
            res.status(500).json({"message": `error al actualizar la imagen . Err: ${err}`})
        }
       
    },

    deleteImage: async(req,res) => {
        // aqui solo tengo un campo en la base pero haqu que agregar comas si hay mas
        const id = req.params.id
        try{
            const user = await UserServices.deleteImage(id)

            res.status(200).json(user)
        } catch(err){
            res.status(500).json({"message": `error al borrar la imagen . Err: ${err}`})
        }
       
    },
    // aqui agregar las otras funciones 
}