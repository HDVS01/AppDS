const UserServices = require('../services/video_clues.js')
module.exports = {
    getAllVideo_Clues : async(req,res,next) => {
        try{
            const users = await UserServices.getAllVideo_Clues()

            res.json(users)
        } catch(err){
            res.json({"message": 'error al obtener las pistas video . Err: ${err}'})
        }
       
    },
    getVideo_Clue: async(req,res) => {
        const id = req.params.id
        try{
            const user = await UserServices.getVideo_Clue(id)

            res.json(user)
        } catch(err){
            res.json({"message": `error al obtener la pista video . Err: ${err}`})
        }
       
    },
    addVideo_Clue: async(req,res) => {
        // aqui solo tengo un campo en la base pero haqu que agregar comas si hay mas
        const body = req.body
        try{
            const user = await UserServices.addVideo_Clue(body)

            res.status(200).json(user)
        } catch(err){
            res.status(500).json({"message": `error al agregar la pista video . Err: ${err}`})
        }
       
    },
    updateVideo_Clue: async(req,res) => {
        // aqui solo tengo un campo en la base pero haqu que agregar comas si hay mas
        const id = req.params.id
        const body = req.body
        try{
            const user = await UserServices.updateVideo_Clue(id, body)

            res.status(200).json(user)
        } catch(err){
            res.status(500).json({"message": `error al actualizar la pista video . Err: ${err}`})
        }
       
    },

    deleteVideo_Clue: async(req,res) => {
        // aqui solo tengo un campo en la base pero haqu que agregar comas si hay mas
        const id = req.params.id
        try{
            const user = await UserServices.deleteVideo_Clue(id)

            res.status(200).json(user)
        } catch(err){
            res.status(500).json({"message": `error al borrar la pista video . Err: ${err}`})
        }
       
    },
    // aqui agregar las otras funciones 
}