const UserServices = require('../services/sessions.js')
module.exports = {
    getAllSessions : async(req,res,next) => {
        try{
            const users = await UserServices.getAllSessions()

            res.json(users)
        } catch(err){
            res.json({"message": 'error al obtener las sesiones . Err: ${err}'})
        }
       
    },
    getSession: async(req,res) => {
        const id = req.params.id
        try{
            const user = await UserServices.getSession(id)

            res.json(user)
        } catch(err){
            res.json({"message": `error al obtener la sesion . Err: ${err}`})
        }
       
    },
    addSession: async(req,res) => {
        // aqui solo tengo un campo en la base pero haqu que agregar comas si hay mas
        const body = req.body
        try{
            const user = await UserServices.addSession(body)

            res.status(200).json(user)
        } catch(err){
            res.status(500).json({"message": `error al agregar la sesion . Err: ${err}`})
        }
       
    },
    updateSession: async(req,res) => {
        // aqui solo tengo un campo en la base pero haqu que agregar comas si hay mas
        const id = req.params.id
        const body = req.body
        try{
            const user = await UserServices.updateSession(id, body)

            res.status(200).json(user)
        } catch(err){
            res.status(500).json({"message": `error al actualizar la sesion . Err: ${err}`})
        }
       
    },

    deleteSession: async(req,res) => {
        // aqui solo tengo un campo en la base pero haqu que agregar comas si hay mas
        const id = req.params.id
        try{
            const user = await UserServices.deleteSession(id)

            res.status(200).json(user)
        } catch(err){
            res.status(500).json({"message": `error al borrar la categoria . Err: ${err}`})
        }
       
    },
    // aqui agregar las otras funciones 
}